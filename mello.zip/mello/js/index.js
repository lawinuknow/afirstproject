const deltagande = [
    "Elisa Lindström",
    "Adam Woods",
    "Dear Sara",
    "Fröken Snusk",
    "Klaudy",
    "Gunilla Persson",
    "Albin Tingwall",
    "Scarlet",
]
let state = 0
const buttonNext = document.getElementById("next")
const buttonVote = document.getElementById("vote")
const buttonBack = document.getElementById("back")
const image = document.getElementById("del")

let aname = document.querySelector("#deln span")


const getName = (s) => deltagande[s]

buttonNext.onclick = () => {//NEXT
    
    if (state === deltagande.length -1) {
        state = 0
        
        aname.innerHTML = getName(state)
        
        image.src = `./imgs/${deltagande[state]}.avif`
    }
    else {
        state++;
        aname.innerHTML = getName(state)
        image.src = `./imgs/${deltagande[state]}.avif`
    }

    
}

buttonBack.onclick = () => {//BACK
    if (state === 0) {
        state = 7
        aname.innerHTML = getName(state)
        
        image.src = `./imgs/${deltagande[state]}.avif`
    }
    else {
        state--;
        aname.innerHTML = getName(state)
        image.src = `./imgs/${deltagande[state]}.avif`
    }
    
    name = getName(state)
}

buttonVote.onclick = () => {
    

    buttonVote.style.backgroundColor = "red";
    buttonVote.innerHTML = "Voted!"
    buttonVote.setAttribute("disabled", "true")
}